# AliyunMqttArduino: Change Log

## v0.2.0 (Feb. 14th, 2019)

* Add two new APIs to support calculate HMAC256 externally for resource limited device like Arduino UNO.
* Update README.
* Add UNO example.

## v0.1.1 (Jan. 2019)

* Include examples code in library release.
* Add changelog file.

## v0.1.0

* Initial release to PIO registry and validated with Node MCU v3.
